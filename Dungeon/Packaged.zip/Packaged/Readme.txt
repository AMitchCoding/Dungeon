How to make the executable usable.

Change "Dungeon.not_an_exe" to "Dungeon.exe"

Various methods of sharing I've used are picky about having executable files in files to transfered so this seemed like an easy solution.